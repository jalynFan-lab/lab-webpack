const path = require("path")
const { VueLoaderPlugin } = require("vue-loader");

module.exports = {
    mode: 'development',
    entry:"./src/js/main.js",
    output:{
        path:path.resolve(__dirname,"dist"),
        filename:"bundle.js",
        publicPath:'./dist/'
    },
    module: {
        rules: [
          {
            test: /\.css$/i,
            use: ["style-loader", "css-loader"],
          },
          {
            test: /\.less$/i,
            use: [
              {
                loader: "style-loader",
              },
              {
                loader: "css-loader",
              },
              {
                loader: "less-loader",
              },
            ],
          },
          {
            test: /\.(png|jpg|gif|jpeg)$/i,
            use: [
              {
                loader: 'url-loader',
                options: {
                  limit: 13000,//超过这个值的需要使用file-loader
                  name:'img/[name].[hash:8].[ext]',//给图片重命名
                  esModule: false //解决图片加载不出来的问题
                },
              },
            ],
          },
          {
            test: /\.m?js$/,
            exclude: /(node_modules|bower_components)/,
            use: {
              loader: 'babel-loader',
              options: {
                presets: ['@babel/preset-env']
              }
            }
          },
          {
            test: /\.vue$/,
            use: {
              loader: 'vue-loader'
            }
          }
        ],
      },
    resolve:{
      extensions:['.js','.vue'],
      alias:{
        //js文件中import vue的时候先指向“'vue/dist/vue.esm.js'”，而不是默认的
        'vue$':'vue/dist/vue.esm.js'
      }
    },
    plugins: [
      new VueLoaderPlugin()
    ]
    
}