const {sum} = require("./Util")

console.log(sum(1,4))

require("../css/common.css")
require("../css/special.less")


//使用vue模块化开发
import Vue from 'vue'
//import App from '../vue/' 
import App from '../vue/App'

new Vue({
    el:'#app',
    template:'<App/>',
    components:{
      App
    }

})