export default{
    template:`
    <div>
    <h2>{{message}}</h2>
    <button @click="btnClick">BUTTON</button>
    </div>
    `,
    data:{
        message:'O_O hello webpack'
    },
    methods:{
        btnClick(){

        }
    }
}