<template>
     <div>
        <h2>{{message}}</h2>
        <button @click="btnClick">BUTTON</button>
        <Cpn/>
    </div>
</template>

<script>
import Cpn from '../vue/Cpn'
export default {
    name:"App",
    components:{
        Cpn
    },
    data(){
        return{
           message:'O_O hello webpack'
        }
     
    },
    methods:{
        btnClick(){

        }
    }
}
</script>