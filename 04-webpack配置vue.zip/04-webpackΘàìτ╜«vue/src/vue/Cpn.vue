<template>
    <div>
        <h2 class="title">(((((((O_O))))))){{username}}</h2>
    </div>
</template>
<script>
export default {
    name:"Cpn",
    data(){
        return{
          username:"fan"
        }
      
    }
}
</script>
<style>
.title{
    color:green
}
</style>