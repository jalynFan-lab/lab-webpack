### 1-1 package.json
scripts 中的命令会优先找本地的然后找不到的情况下会找全局
### 1-2 npm install webpack@3.6.0 --save-dev 
安装局部的webpack
### 1-3 npm install webpack@3.6.0 -g
安装全局的webpack


