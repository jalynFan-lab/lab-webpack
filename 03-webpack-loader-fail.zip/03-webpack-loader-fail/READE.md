### loader的概念
webpack主要处理js代码，但是其他转换成js就需要webpack拓展loader

