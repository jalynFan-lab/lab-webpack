const path = require("path")

module.exports = {
    entry:"./src/js/main.js",
    output:{
        path:path.resolve(__dirname,"dist"),
        filename:"bundle.js"
    },
    module: {
        rules: [
          {
            test: /\.css$/,
            //css-loader 只加载css文件，
            //style-loader 将样式添加到dom中
            //使用多个loader的时候从右向左解析
            use: [
                {loader: 'style-loader',
                loader: "css-loader"} 
            ],
          },
        ],
      }
}