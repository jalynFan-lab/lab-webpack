//commonjs 模块
const {sum} = require("./Util")

console.log(sum(1,4))

//依赖css文件
require("../css");